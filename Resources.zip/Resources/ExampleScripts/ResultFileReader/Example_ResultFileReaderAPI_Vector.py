# Example_ResultFileReaderAPI_Vector.py
import sys

# BINARY_FOLDER_PATH : path to the folder containing the Postprocessor dll files
# RESULT_FILE_READER_API_MODULE_PATH : path to the folder containing ResultFileReaderAPI.py
sys.path.append(BINARY_FOLDER_PATH)
sys.path.append(RESULT_FILE_READER_API_MODULE_PATH)

# Import necessary modules
from ResultFileReaderAPI import *

# RESULT_FILE_PATH : .dfr result file path
output_reader = OutputReader(RESULT_FILE_PATH)

print ("===GetVector===")
# target : Specifies the name of vector displayable entity
# path : Specifies characteristc on vector display
entity_name = "TJ_01"
# characteristic_name : vector characteristic for the Action Force result
characteristic_name = "Action Force"
vectors = output_reader.GetVector(entity_name, characteristic_name)
for vector in vectors:
    print(f"Vector : {vector.Key}")
    animation_data = vector.Value

    position_count = len(list(animation_data.Positions))
    for i in range(position_count):
        first_position_count = len(list(animation_data.Positions[i]))
        for j in range(first_position_count):
            second_positions = list(animation_data.Positions[i][j])
            print("Positions :", *second_positions, sep=',')

    vector_count = len(list(animation_data.Vectors))
    for i in range(vector_count):
        first_vector_count = len(list(animation_data.Vectors[i]))
        for j in range(first_vector_count):
            second_vectors = list(animation_data.Vectors[i][j])
            print("Vectors :", *second_vectors, sep=',')
# Close
output_reader.Close()

# Example_ResultFileReaderAPI_GetContour.py
import sys

# BINARY_FOLDER_PATH : path to the folder containing the Postprocessor dll files
# RESULT_FILE_READER_API_MODULE_PATH : path to the folder containing ResultFileReaderAPI.py
sys.path.append(BINARY_FOLDER_PATH)
sys.path.append(RESULT_FILE_READER_API_MODULE_PATH)

# Import necessary modules
from ResultFileReaderAPI import *

# RESULT_FILE_PATH : .dfr result file path
output_reader = OutputReader(RESULT_FILE_PATH)

# State ID Array
state_ids = output_reader.GetStateIDArray()

# Select the entity and the characteristic/component path to read.
entity_name = "FEBody_01"
# characteristic_name : characteristic/component path for the Top Stress X contour result
characteristic_name = "Top Stress/X"

# Define the callback that receives contour values for each state.
def write_result(state_id, result_groups):
    print(f"State ID: {state_id}")
    print(f"Value groups: {len(result_groups)}")
action = Action[Int32, IList[Array[Double]]](write_result)

# Read contour values for the selected entity and each requested state.
output_reader.GetContourResult(
    state_ids,
    entity_name,
    ContourMappingType.FENode,
    characteristic_name,
    action,
    AnalysisResultType.Dynamics,
)

# Close
output_reader.Close()

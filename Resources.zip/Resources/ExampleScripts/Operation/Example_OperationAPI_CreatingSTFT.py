# Example_OperationAPI_CreatingSTFT.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Set array about result file
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path
filepaths.Add(RESULT_FILE_PATH)

# Open about result files
# This will open the result file in the application.
# When the result is first opened, a Page is created and an Animation View is created on that Page.
application_handler.AddDocument(filepaths)

# Get Active Page
# This retrieves the currently active page in the application.
page = application_handler.GetActivePage()

# Creating a Chart
# Create a new Chart View on the page
# This will create a new chart view with the specified name.
chart_name = "Chart"
chart_view = page.CreateChart(chart_name)

# Specify the paths for the curves you want to retrieve.
# For example, Acceleration represents the Characteristic, and Y after the / represents the Component.
# In this case, we are retrieving the Y component of Acceleration for the Crank.
# You can check the available Characteristics and Components for the target by using Add Curve in the Postprocessor.
curve_paths = List[str]()
# characteristic_path_magnitude : characteristic/component path of the curve to add, in "Characteristic/Component" format
characteristic_path_magnitude = r'Displacement/Magnitude'
curve_paths.Add(characteristic_path_magnitude)

# Create a PlotParameters object to specify the parameters for the plot.
# Set the Entity to Plot.
# The Target is the name of the target for which you want to retrieve the curves.
# Set the paths for the curves you want to retrieve.
# This is where you specify the characteristics and components you want to plot.
parameters = PlotParameters()
parameters.Paths = curve_paths
entity_name = "Crank"
parameters.Target = entity_name

# Add Curves (FilePath, Curve Parameter)
# FilePath : The path of the result to access.
# parameters : The class used as a parameter of the AddCurve function.
# The instance of the curve.
curves = chart_view.AddCurves(RESULT_FILE_PATH, parameters)

# Documentation Example
# SeriesNames : The list of the curve name to perform the operation
curve_names = List[str]()
for curve in curves :
    curve_names.Add(curve.SeriesName)

# SamplingFrequency : the number of the interval for dividing Y direction grids on color map.
# TimeSlice : the number of the interval for dividing  X direction grids on color map.
# Overlap : the value of the percentage for setting overlapped intervals.
# SelectedPoints : the number of data point for FFT.
# Start : the start time for using FFT on target data series.
# End : the end time for using FFT on target data series.
# ReferenceValue : the reference value on decibel as the type of the scale.
# ScaleFactor : the scale factor to change from time domain to another domain.
# SelectedScaleType : the scale type of STFT. STFT Scale Type has Original, Decibel.
stft_parameters = STFTParameters()
stft_parameters.SamplingFrequency = 100
stft_parameters.TimeSlice = 0.05
stft_parameters.Overlap = 50
stft_parameters.SelectedPoints = 16384
stft_parameters.Start = 0
stft_parameters.End = 1.000000000001
stft_parameters.ReferenceValue = 1E-05
stft_parameters.ScaleFactor = 1.0
stft_parameters.SelectedScaleType = STFTScaleType.Original
chart_view.CreateSTFT(stft_parameters, curve_names)

# Close the Pages
page.Close()

# Close the Document
application_handler.CloseDocument(RESULT_FILE_PATH)
